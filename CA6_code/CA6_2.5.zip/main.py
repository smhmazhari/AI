from snake import *
from utility import *
from cube import *
import pygame
import numpy as np
from tkinter import messagebox
import matplotlib.pyplot as plt



plt.ion()
fig, (ax1, ax2) = plt.subplots(2, 1)
x = []
y_reward1 = []
y_length1 = []
y_reward2 = [] 
y_length2 = [] 


(line_reward1,) = ax1.plot(x, y_reward1, label="Snake 1 - Avg Reward", color="blue")
(line_reward2,) = ax1.plot(x, y_reward2, label="Snake 2 - Avg Reward", color="red")
ax1.set_xlabel("Episode")
ax1.set_ylabel("Average Reward")
ax1.set_title("Snake Game Training Progress - Rewards")
ax1.legend()


(line_length1,) = ax2.plot(x, y_length1, label="Snake 1 - Avg Length", color="green")
(line_length2,) = ax2.plot(x, y_length2, label="Snake 2 - Avg Length", color="orange")
ax2.set_xlabel("Episode")
ax2.set_ylabel("Average Length")
ax2.set_title("Snake Game Training Progress - Length")
ax2.legend()

plt.tight_layout()  



def main():
    print("LEARNING_RATE: ",LEARNING_RATE)
    print("DISCOUNT_FACTOR",DISCOUNT_FACTOR)
    print("EPSILON",EPSILON)
    
    pygame.init()
    win = pygame.display.set_mode((WIDTH, HEIGHT))

    snake_1 = Snake((255, 0, 0), (15, 15), SNAKE_1_Q_TABLE)
    snake_2 = Snake((255, 255, 0), (5, 5), SNAKE_2_Q_TABLE)
    snake_1.addCube()
    snake_2.addCube()

    snack = Cube(randomSnack(ROWS, snake_1), color=(0, 255, 0))

    clock = pygame.time.Clock()

    episode = 0
    episode_rewards1 = []
    episode_lengths1 = []
    episode_rewards2 = []
    episode_lengths2 = []



    
    font_style = pygame.font.SysFont(None, 30)
    def display_score(total_win1, total_win2):
        score_text1 = font_style.render("Snake 1 Score: " + str(total_win1), True, (255, 255, 255))
        score_text2 = font_style.render("Snake 2 Score: " + str(total_win2), True, (255, 255, 255))
        win.blit(score_text1, [0, 0])
        win.blit(score_text2, [WIDTH - score_text2.get_width(), 0])

    total_win1 = 0 
    total_win2 = 0 
    while True:
        reward_1 = 0
        reward_2 = 0
        pygame.time.delay(10)
        clock.tick(350)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if messagebox.askokcancel("Quit", "Do you want to save the Q-tables?"):
                    save(snake_1, snake_2)
                pygame.quit()
                snake_1.print_info()
                snake_2.print_info()
                exit()

            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                np.save(SNAKE_1_Q_TABLE, snake_1.q_table)
                np.save(SNAKE_2_Q_TABLE, snake_2.q_table)
                pygame.time.delay(1000)

        state_1, new_state_1, action_1 = snake_1.move(snack, snake_2)
        state_2, new_state_2, action_2 = snake_2.move(snack, snake_1)

        snack, reward_1, win_1, win_2 = snake_1.calc_reward(snack, snake_2)
        if win_1 :
            total_win1 += 1
        if win_2 :
            total_win2 += 1
        snack, reward_2, win_2, win_1 = snake_2.calc_reward(snack, snake_1)


        episode_rewards1.append(reward_1)
        episode_lengths1.append(len(snake_1.body))
        episode_rewards2.append(reward_2)
        episode_lengths2.append(len(snake_2.body))

        snake_1.update_q_table(state_1, action_1, new_state_1, reward_1)
        snake_2.update_q_table(state_2, action_2, new_state_2, reward_2)

        redrawWindow(snake_1, snake_2, snack, win)
        display_score(total_win1, total_win2) 
        pygame.display.update()  
        
        if win_1 :
            total_win1 += 1
        if win_2 :
            total_win2 += 1
        if win_1 or win_2:  
            episode += 1


            avg_reward1 = np.mean(episode_rewards1)
            avg_length1 = np.mean(episode_lengths1)
            avg_reward2 = np.mean(episode_rewards2)
            avg_length2 = np.mean(episode_lengths2)


            x.append(episode)
            y_reward1.append(avg_reward1)
            y_length1.append(avg_length1)
            y_reward2.append(avg_reward2)
            y_length2.append(avg_length2)


            line_reward1.set_data(x, y_reward1)
            line_length1.set_data(x, y_length1)
            line_reward2.set_data(x, y_reward2)
            line_length2.set_data(x, y_length2)


            ax1.relim()
            ax1.autoscale_view()
            ax2.relim()
            ax2.autoscale_view()


            fig.canvas.draw()
            fig.canvas.flush_events()


            episode_rewards1 = []
            episode_lengths1 = []
            episode_rewards2 = []
            episode_lengths2 = []

if __name__ == "__main__":
    main()